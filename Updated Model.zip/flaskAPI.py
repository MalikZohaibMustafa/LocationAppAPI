from flask import Flask, request, jsonify
import pickle
from flask_cors import CORS


app = Flask(__name__)
CORS(app)

# Load the saved model
with open("./mechanics_model.pkl", "rb") as file:
    kdtree, train_data, specialty_mapping = pickle.load(file)

@app.route('/nearest_mechanics', methods=['POST'])
def get_nearest_mechanics():
    data = request.get_json(force=True)
    user_lat = data['latitude']
    user_lon = data['longitude']
    specialty = data['specialty']

    if specialty not in specialty_mapping:
        return jsonify({"error": "Invalid specialty provided."})

    # Query the KD-tree to find the nearest neighbors
    distances, indices = kdtree.query([[user_lat, user_lon]], k=5)
    
    # Filter the results based on the provided specialty
    nearest_mechanics = train_data.iloc[indices[0]]
    nearest_mechanics = nearest_mechanics[nearest_mechanics['Specialty_encoded'] == specialty_mapping[specialty]]

    # Check if any mechanics were found
    if nearest_mechanics.empty:
        return jsonify(["No mechanic found."])

    # Convert the results to JSON format
    results = nearest_mechanics[['Name', 'Phone Number', 'ID Number']].to_dict(orient="records")
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
