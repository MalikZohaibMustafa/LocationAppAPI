import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KDTree
import pickle

# Data Loading
data_path = "./updated_mechanics_data_google.csv"  
mechanics_data = pd.read_csv(data_path)

# Handling missing values
mechanics_data = mechanics_data.dropna(subset=['Latitude', 'Longitude', 'Specialty'])

# Remove outliers using IQR method for Latitude and Longitude
Q1_lat = mechanics_data['Latitude'].quantile(0.25)
Q3_lat = mechanics_data['Latitude'].quantile(0.75)
IQR_lat = Q3_lat - Q1_lat
lower_bound_lat = Q1_lat - 1.5 * IQR_lat
upper_bound_lat = Q3_lat + 1.5 * IQR_lat
mechanics_data = mechanics_data[(mechanics_data['Latitude'] >= lower_bound_lat) & (mechanics_data['Latitude'] <= upper_bound_lat)]

Q1_lon = mechanics_data['Longitude'].quantile(0.25)
Q3_lon = mechanics_data['Longitude'].quantile(0.75)
IQR_lon = Q3_lon - Q1_lon
lower_bound_lon = Q1_lon - 1.5 * IQR_lon
upper_bound_lon = Q3_lon + 1.5 * IQR_lon
mechanics_data = mechanics_data[(mechanics_data['Longitude'] >= lower_bound_lon) & (mechanics_data['Longitude'] <= upper_bound_lon)]

# Model Generation (KD-tree)
specialty_mapping = {specialty: i for i, specialty in enumerate(mechanics_data['Specialty'].unique())}
mechanics_data['Specialty_encoded'] = mechanics_data['Specialty'].map(specialty_mapping)
train_data, _ = train_test_split(mechanics_data, test_size=0.2, random_state=42)
coordinates = train_data[['Latitude', 'Longitude']].values
kdtree = KDTree(coordinates)

# Save the KD-tree and additional data as a .pkl file
with open("./mechanics_model.pkl", "wb") as file:
    pickle.dump((kdtree, train_data, specialty_mapping), file)

print("Model saved successfully!")
# Function to predict nearest mechanics (up to 5)
def predict_nearest_mechanics(lat, lon, specialty):
    if specialty not in specialty_mapping:
        return {"error": "Invalid specialty provided."}
    
    # Query the KD-tree to find the nearest neighbors (up to 5)
    distances, indices = kdtree.query([[lat, lon]], k=5)
    
    # Filter the results based on the provided specialty
    nearest_mechanics = train_data.iloc[indices[0]]
    nearest_mechanics = nearest_mechanics[nearest_mechanics['Specialty_encoded'] == specialty_mapping[specialty]]
    
    # Check if any mechanics were found
    if nearest_mechanics.empty:
        return ["No mechanic found."]
    
    # Return the details of the nearest mechanics
    return nearest_mechanics[['Name', 'Phone Number', 'ID Number']].head(5).to_dict(orient="records")

# # Predicting for dummy test cases
# test_samples = mechanics_data.sample(5)  # Taking 5 random samples
# predictions = []
# for _, sample in test_samples.iterrows():
#     result = predict_nearest_mechanics(sample['Latitude'], sample['Longitude'], sample['Specialty'])
#     predictions.append({
#         "Input": {
#             "Latitude": sample['Latitude'],
#             "Longitude": sample['Longitude'],
#             "Specialty": sample['Specialty']
#         },
#         "Output": result
#     })

# print(predictions)